  @model IEnumerable<GroupProject.Models.UsersAccount>

    @{
        ViewBag.Title = "Index";
        Layout = "~/Views/Shared/_Layout.cshtml";
    }

    <h2>Index</h2>

    <p>
        @Html.ActionLink("Create New", "Create")
    </p>
    <table class="table">
        <tr>
            <th>
                @Html.DisplayNameFor(model => model.FirstName)
            </th>
            <th>
                @Html.DisplayNameFor(model => model.LastName)
            </th>
            <th>
                @Html.DisplayNameFor(model => model.Email)
            </th>
            <th>
                @Html.DisplayNameFor(model => model.UserName)
            </th>
            @*<th>
                    @Html.DisplayNameFor(model => model.Password)
                </th>
                <th>
                    @Html.DisplayNameFor(model => model.ConfirmPassword)
                </th>
                <th></th>*@
        </tr>

        @foreach (var item in Model)
        {
            <tr>
                <td>
                    @Html.DisplayFor(modelItem => item.FirstName)
                </td>
                <td>
                    @Html.DisplayFor(modelItem => item.LastName)
                </td>
                <td>
                    @Html.DisplayFor(modelItem => item.Email)
                </td>
                <td>
                    @Html.DisplayFor(modelItem => item.UserName)
                </td>
                @*<td>
                        @Html.DisplayFor(modelItem => item.Password)
                    </td>
                    <td>
                        @Html.DisplayFor(modelItem => item.ConfirmPassword)
                    </td>*@
                <td>
                    @Html.ActionLink("Edit", "Edit", new { id = item.UserId }) |
                    @Html.ActionLink("Details", "Details", new { id = item.UserId }) |
                    @Html.ActionLink("Delete", "Delete", new { id = item.UserId })
                </td>
            </tr>
        }

    </table>

    <div>
        @Html.ActionLink("Back to Login Page", "Login", "Account")
    </div>
