﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatApplication_VT
{
    class Menu
    {

        public static void AdministratorMenu(string username)
        {
            char choice;
            for (; ; )
            {
                do
                {
                    Console.WriteLine("-----------Welcome to Administartor Menu-------");
                    Console.WriteLine("  a. Create a new User");
                    Console.WriteLine("  b. Delete a User");
                    Console.WriteLine("  c. Update  Name of a user ");
                    Console.WriteLine("  d. Update Password of a user");
                    Console.WriteLine("  e. Change the Role of a User");
                    Console.WriteLine("  f. View All Messages");
                    Console.WriteLine("  g. Send a Message");
                    Console.WriteLine("  h. Update a Message");
                    Console.WriteLine("  i. Delete a Message");
                    Console.WriteLine("  j. Main Menu");
                    Console.Write("Quit (q to quit):");

                    do
                    {
                        choice = (char)Console.Read();
                    } while (choice == '\n' | choice == '\r');
                } while (choice < 'a' | choice > 'j' & choice != 'q');

                if (choice == 'q') break;

                Console.WriteLine("\n");

                switch (choice)
                {
                    case 'a':
                        Users.CreateUser();
                        AdministratorMenu(username);
                        break;
                    case 'b':
                        Users.DeleteUser(username);
                        AdministratorMenu(username);
                        break;
                    case 'c':
                        Users.UpdateNameByAdmin(username);
                        AdministratorMenu(username);
                        break;
                    case 'd':
                        Users.UpdateUserPassWordByAdmin(username);
                        AdministratorMenu(username);
                        break;
                    case 'e':
                        Users.ChangeRole();
                        AdministratorMenu(username);
                        break;
                    case 'f':
                        Messages.ViewAllMessages();
                        ViewerMenu(username);
                        break;
                    case 'g':
                        Messages.NewMessage(username,username);
                        ViewerMenu(username);
                        break;
                    case 'h':
                        string input1 = "";
                        double idToUpdateMessage = 0;
                        do
                        {
                            Console.WriteLine("Enter the id of the message you want to update : ");

                            input1 = Console.ReadLine();
                            if (!double.TryParse(input1, out idToUpdateMessage))
                                Console.WriteLine("Input is not a number. Please try again . . . ");
                        } while (!double.TryParse(input1, out idToUpdateMessage));

                        Messages.UpdateMessage(idToUpdateMessage);
                        break;
                    case 'i':
                        string input2 = "";
                        int idToDeleteMessage = 0;
                        do
                        {
                            Console.WriteLine("Enter the id of the message you want to delete : ");
                            input2 = Console.ReadLine();
                            if (!int.TryParse(input2, out idToDeleteMessage))
                                Console.WriteLine("Input is not a number. Please try again . . . ");
                        } while (!int.TryParse(input2, out idToDeleteMessage));

                        Messages.DeleteMessage(idToDeleteMessage);
                        SimpleUserMenu(username);
                        break;
                    case 'j':
                        AdministratorMenu(username);
                        break;
                    default:
                        Console.WriteLine("Invalid Entry!");
                        break;
                }
                Console.WriteLine();
            }
        }

        public static void SimpleUserMenu(string username)
        {
            char choice;
            for (; ; )
            {
                do
                {
                    Console.WriteLine("-----------Welcome to Simple User Menu-------");
                    Console.WriteLine("  1. Update your Name");
                    Console.WriteLine("  2. Update your UserName");
                    Console.WriteLine("  3. Update your Password  ");
                    Console.WriteLine("  4. Send a Message");
                    Console.WriteLine("  5. Update a Message");
                    Console.WriteLine("  6. Delete a Message");
                    Console.Write("Quit (q to quit):");
                    do
                    {
                        choice = (char)Console.Read();
                    } while (choice == '\n' | choice == '\r');
                } while (choice < '1' | choice > '8' & choice != 'q');

                if (choice == 'q') break;

                Console.WriteLine("\n");

                switch (choice)
                {
                    case '1':
                        Users.UpdateName(username);
                        SimpleUserMenu(username);
                        break;
                    case '2':
                        Users.UpdateUserName(username);
                        SimpleUserMenu(username);
                        break;
                    case '3':
                        Users.UpdateUserPassWord(username);
                        SimpleUserMenu(username);
                        break;
                    case '4':
                        Messages.NewMessage(username, username);
                        SimpleUserMenu(username);
                        break;
                    case '5':
                        string input1 = "";
                        double idToUpdateMessage = 0;
                        do
                        {
                            Console.WriteLine("Enter the id of the message you want to update : ");

                            input1 = Console.ReadLine();
                            if (!double.TryParse(input1, out idToUpdateMessage))
                                Console.WriteLine("Input is not a number. Please try again . . . ");
                        } while (!double.TryParse(input1, out idToUpdateMessage));

                        Messages.UpdateMessage(idToUpdateMessage);
                        SimpleUserMenu(username);
                        break;
                    case '6':
                        string input2 = "";
                        int idToDeleteMessage = 0;
                        do
                        {
                            Console.WriteLine("Enter the id of the message you want to delete : ");
                            input2 = Console.ReadLine();
                            if (!int.TryParse(input2, out idToDeleteMessage))
                                Console.WriteLine("Input is not a number. Please try again . . . ");
                        } while (!int.TryParse(input2, out idToDeleteMessage));

                        Messages.DeleteMessage(idToDeleteMessage);
                        SimpleUserMenu(username);
                        break;                        
                    default:
                        Console.WriteLine("Invalid Entry!");
                        break;
                }
                Console.WriteLine();
            }

        }

        public static void ViewerMenu(string username)
        {
            char choice;
            for (; ; )
            {
                do
                {
                    Console.WriteLine("-----------Welcome to View User Menu-------");
                    Console.WriteLine("  1. Update your Name");
                    Console.WriteLine("  2. Update your UserName");
                    Console.WriteLine("  3. Update your Password  ");
                    Console.WriteLine("  4. Send a Message");
                    Console.WriteLine("  5. View All messages");
                    Console.Write("Quit (q to quit):");
                    do
                    {
                        choice = (char)Console.Read();
                    } while (choice == '\n' | choice == '\r');
                } while (choice < '1' | choice > '8' & choice != 'q');

                if (choice == 'q') break;

                Console.WriteLine("\n");

                switch (choice)
                {
                    case '1':
                        Users.UpdateName(username);
                        ViewerMenu(username);
                        break;
                    case '2':
                        Users.UpdateUserName(username);
                        ViewerMenu(username);
                        break;
                    case '3':
                        Users.UpdateUserPassWord(username);
                        ViewerMenu(username);
                        break;
                    case '4':
                        Messages.NewMessage(username, username);
                        ViewerMenu(username);
                        break;
                    case '5':
                        Messages.ViewAllMessages();
                        ViewerMenu(username);
                        break;
                    default:
                        Console.WriteLine("Invalid Entry!");
                        break;
                }
                Console.WriteLine();
            }




        }

        public static void EditorMenu(string username)
        {
            char choice;
            for (; ; )
            {
                do
                {
                    Console.WriteLine("-----------Welcome to Editor User Menu-------");
                    Console.WriteLine("  1. Update your Name");
                    Console.WriteLine("  2. Update your UserName");
                    Console.WriteLine("  3. Update your Password  ");
                    Console.WriteLine("  4. Send a Message");
                    Console.WriteLine("  5. View All messages");
                    Console.WriteLine("  6. Update a message");
                    Console.Write("Quit (q to quit):");
                    do
                    {
                        choice = (char)Console.Read();
                    } while (choice == '\n' | choice == '\r');
                } while (choice < '1' | choice > '8' & choice != 'q');

                if (choice == 'q') break;

                Console.WriteLine("\n");

                switch (choice)
                {
                    case '1':
                        Users.UpdateName(username);
                        EditorMenu(username);
                        break;
                    case '2':
                        Users.UpdateUserName(username);
                        EditorMenu(username);
                        break;
                    case '3':
                        Users.UpdateUserPassWord(username);
                        EditorMenu(username);
                        break;
                    case '4':
                        Messages.NewMessage(username, username);
                        EditorMenu(username);
                        break;
                    case '5':
                        Messages.ViewAllMessages();
                        EditorMenu(username);
                        break;
                    case '6':
                        string input1 = "";
                        double idToUpdateMessage = 0;
                        do
                        {
                            Console.WriteLine("Enter the id of the message you want to update : ");

                            input1 = Console.ReadLine();
                            if (!double.TryParse(input1, out idToUpdateMessage))
                                Console.WriteLine("Input is not a number. Please try again . . . ");
                        } while (!double.TryParse(input1, out idToUpdateMessage));

                        Messages.UpdateMessage(idToUpdateMessage);
                        EditorMenu(username);
                        break;
                    default:
                        Console.WriteLine("Invalid Entry!");
                        break;
                }
                Console.WriteLine();
            }
        }

        public static void DeletorMenu(string username)
        {
            char choice;
            for (; ; )
            {
                do
                {
                    Console.WriteLine("-----------Welcome to Deletor User Menu-------");
                    Console.WriteLine("  1. Update your Name");
                    Console.WriteLine("  2. Update your UserName");
                    Console.WriteLine("  3. Update your Password  ");
                    Console.WriteLine("  4. Send a Message");
                    Console.WriteLine("  5. View All messages");
                    Console.WriteLine("  6. Delete a message");
                    Console.Write("Quit (q to quit):");
                    do
                    {
                        choice = (char)Console.Read();
                    } while (choice == '\n' | choice == '\r');
                } while (choice < '1' | choice > '8' & choice != 'q');

                if (choice == 'q') break;

                Console.WriteLine("\n");

                switch (choice)
                {
                    case '1':
                        Users.UpdateName(username);
                        DeletorMenu(username);
                        break;
                    case '2':
                        Users.UpdateUserName(username);
                        DeletorMenu(username);
                        break;
                    case '3':
                        Users.UpdateUserPassWord(username);
                        DeletorMenu(username);
                        break;
                    case '4':
                        Messages.NewMessage(username, username);
                        DeletorMenu(username);
                        break;
                    case '5':
                        Messages.ViewAllMessages();
                        DeletorMenu(username);
                        break;
                    case '6':
                        string input1 = "";
                        int idToDeleteMessage = 0;
                        do
                        {
                            Console.WriteLine("Enter the id of the message you want to delete : ");

                            input1 = Console.ReadLine();
                            if (!int.TryParse(input1, out idToDeleteMessage))
                                Console.WriteLine("Input is not a number. Please try again . . . ");
                        } while (!int.TryParse(input1, out idToDeleteMessage));

                        Messages.DeleteMessage(idToDeleteMessage);
                        DeletorMenu(username);
                        break;
                    default:
                        Console.WriteLine("Invalid Entry!");
                        break;
                }
                Console.WriteLine();
            }

        }

    }
}
