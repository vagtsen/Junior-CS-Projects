﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace ChatApplication_VT
{

    //This Class is responsible for the Database Access
    class DataBaseAccess : Users
    {
       
        public static SqlConnection Connection() //Method for calling the ConnectionString 
        {

            string connectionString =
            //@"Server = VAGGOS2-LAPTOP\VAGGOS_SERVER;Initial Catalog=Database100;User Id = sa; Password = vaggos123";
            @"Server = VAGGOS1-PC\VAGGOS_SERVER;Initial Catalog=Database100;User Id = sa; Password = vaggos123";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            return sqlConnection;

        }

       // The method checks whether a user exists or not
        public static bool UserExists(string nameforSelect)
        {

            SqlConnection connection = DataBaseAccess.Connection();
            bool value = false;

            using (connection)
            {
                try
                {
                    connection.Open();
                    SqlCommand cmdSelect = new SqlCommand("SELECT COUNT(*) FROM Users WHERE UserName = @username", connection);
                    cmdSelect.Parameters.AddWithValue("@username", $"{nameforSelect}");
                    int result = (int)cmdSelect.ExecuteScalar();

                    if (result > 0)
                    {
                        value = true;
                    }
                    else
                    {
                        value = false;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
                return value;
            }
        }

        public static int GetTheUSerID(string userName)
        {
            SqlConnection connection = DataBaseAccess.Connection();
            int value = 0;
            try
            {
                connection.Open();
                SqlCommand cmdLogin = new SqlCommand($"SELECT UserID FROM Users WHERE UserName = '{userName}'", connection);
                SqlDataReader reader = cmdLogin.ExecuteReader();
                while (reader.Read())
                {
                    value = reader.GetInt32(0); // read the first Column (UserID) of the Table Users

                }
                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
            return value;
        }

        //The method checks the UserName of the User 
        public static string GetTheUSerName(int ID)
        {
            SqlConnection connection = DataBaseAccess.Connection();
            string value = "";
            try
            {
                connection.Open();
                SqlCommand cmdLogin = new SqlCommand($"SELECT UserName FROM Users WHERE UserID = '{ID}'", connection);
                SqlDataReader reader = cmdLogin.ExecuteReader();
                while (reader.Read())
                {
                    value = reader.GetString(3); // value = reader.GetString(0);
                }

                reader.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
            return value;
        }

        //The method is used in the Menu
        public static string GetUserRole(string username)
        {
            SqlConnection connection =DataBaseAccess.Connection();
            string userRole = "";

            try
            {
                connection.Open();

                SqlCommand command = new SqlCommand($"Select Role FROM Users WHERE UserName = '{username}'", connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    userRole = reader["Role"].ToString();
                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
            return userRole;
        }
    }

}

