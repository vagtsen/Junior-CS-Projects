﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatApplication_VT
{
    class Messages
    {
        public int MessageID { get; private set; }
        public DateTime DateOfSubmission { get; private set; }
        public DateTime Updated { get; private set; }
        public string Sender { get; private set; }
        public string Receiver { get; private set; }
        public string MessageText { get; private set; }

        public Messages(int id, DateTime date, string sender, string receiver, string text)
        {
            MessageID = id;
            DateOfSubmission = date;
            Sender = sender;
            Receiver = receiver;
            MessageText = text;
        }


        //The method creates a new message
        public static void NewMessage(string sender, string receiver)
        {
            SqlConnection connection = DataBaseAccess.Connection();
            
            DateTime date = DateTime.Now;
            string messDate = date.ToString("dd/MM/yyyy  HH:mm:ss");

            try
            {

                connection.Open();
                Console.Write("Send a Message: ");
                string newmessage = Console.ReadLine();
                int senderId = DataBaseAccess.GetTheUSerID(sender);
                int receiverId = DataBaseAccess.GetTheUSerID(receiver);
                SqlCommand cmd = new SqlCommand($"INSERT INTO Messages (DateOfSubmission, Sender, Receiver, MessageText) VALUES('{messDate}','{senderId}','{receiverId}','{newmessage}');SELECT SCOPE_IDENTITY();", connection);
                
                string userscontact = $"{sender} to {receiver}";
                FileAccess.CreateMessageToText(messDate, userscontact, newmessage);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "Press any key to continue.");
                Console.ReadKey();
            }
            finally
            {
                connection.Close();
            }
        }

        //The method reads all the Users messages by Administrator
        public static void ViewAllMessages()
        {
            SqlConnection connection = DataBaseAccess.Connection();
            try
            {
                using (connection)
                {
                    connection.Open();
                    Console.WriteLine("------------------------- The Messages Are------------------------ : ");
                    Console.WriteLine();
                    SqlCommand command = new SqlCommand("SELECT MessageID, Sender, Receiver,DateOfSubmission, MessageText FROM Messages;", connection);
                    SqlDataReader reader = command.ExecuteReader();
                    Console.WriteLine("\t" + "MessageID" + "\t" + "Sender" + "\t\t" + "Receiver" + "\t" + "DateOfSubmission" + "\t" + "MessageText");

                    while (reader.Read())
                    {
                        string subject = reader.GetString(4);
                        if (subject.Length > 15)
                            subject = subject.Substring(0, 15);
                        string senderUser = DataBaseAccess.GetTheUSerName(reader.GetInt32(1));
                        string receiverUser = DataBaseAccess.GetTheUSerName(reader.GetInt32(2));
                        Console.WriteLine(String.Format("\t" + $"{reader[0]}" + $"\t{reader[1]}" + $"\t\t  {senderUser}  " + $"\t   {receiverUser} " + $"\t{subject}"));
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            finally
            {
                connection.Close();
            }
        }

        //The method that reads the User's Message
        public static void ViewUserSentMessages(string username)
        {
            SqlConnection connection = DataBaseAccess.Connection();

            try
            {
                int userId = 0;
                using (connection)
                {
                    userId = DataBaseAccess.GetTheUSerID(username);
                    connection.Open();
                    Console.WriteLine("Your Messages are: \n");
                    SqlCommand command = new SqlCommand($"SELECT MessageID, DateOfSubmission, Sender, Receiver, MessageText FROM Messages WHERE Sender = {userId}", connection);
                    SqlDataReader reader = command.ExecuteReader();

                    //Console.WriteLine("\t" + "Id" + "Date" + "Sender" + "Receiver" + "Text");

                    while (reader.Read())
                    {
                        int messageId = reader.GetInt32(0);
                        string receiver = DataBaseAccess.GetTheUSerName(Int32.Parse(reader["Receiver"].ToString()));
                        Console.WriteLine(String.Format("Message Id:" + $"{messageId}\n" + "From:" + username + $"\nTo:{receiver}\n" + "Message: " + $"{reader[4]}\n"));
                    }
                    reader.Close();

                    //Console.WriteLine("Press enter to exit");
                    //Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

        }

        //The method that reads the Receivers' messagses
        public static void ViewUserReceivedMessages(string username)
        {
            SqlConnection connection = DataBaseAccess.Connection();

            try
            {
                int userId = 0;
                using (connection)
                {
                    userId = DataBaseAccess.GetTheUSerID(username);
                    connection.Open();
                    Console.WriteLine("Messages that received: \n");
                    SqlCommand command = new SqlCommand($"SELECT MessageID, DateOfSubmission, Sender, Receiver, MessageText FROM Messages WHERE Receiver = {userId}", connection);
                    SqlDataReader reader = command.ExecuteReader();

                    //Console.WriteLine("\t" + "Id" + "Date" + "Sender" + "Receiver" + "Text");

                    while (reader.Read())
                    {
                        int messageId = reader.GetInt32(0);
                        string sender = DataBaseAccess.GetTheUSerName(Int32.Parse(reader["Sender"].ToString()));
                        Console.WriteLine(String.Format("Message Id:" + $"{messageId}\n" + "From:" + username + $"\nTo:{sender}\n" + "Message: " + $"{reader[4]}\n"));
                    }

                   // Console.WriteLine("Press enter key to exit");
                   // Console.ReadLine();

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

        }

        //The method deletes a message
        public static void DeleteMessage(int messageId)
        {
            SqlConnection connection = DataBaseAccess.Connection();

            try
            {
                using (connection)
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand($"DELETE FROM Messages WHERE MessageID = {messageId}", connection);
                    int deleted = command.ExecuteNonQuery();
                    if (deleted > 0)
                    {
                        Console.WriteLine($"{deleted} rows deleted successfully");
                        Console.WriteLine("Press any key to continue");
                        Console.ReadKey();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

        }

        //The method Edits a message
        public static void UpdateMessage(double ID)
        {
            SqlConnection connection = DataBaseAccess.Connection();
            DateTime date = DateTime.Now;
            var dateOfSubmission = date.ToString("MM/dd/yyyy HH:mm:ss");
            try
            {
               
                Console.WriteLine("Write new message message : ");
                string newMessage = Console.ReadLine();
                connection.Open();
                SqlCommand cmdUpdate = new SqlCommand($"UPDATE Messages SET MessageText = '{newMessage}'' WHERE MessageID = '{ID}'", connection);

                
                int rowsUpdated = cmdUpdate.ExecuteNonQuery();
                if (rowsUpdated > 0)
                {
                    Console.WriteLine("Update Successfull");
                    Console.WriteLine($"{rowsUpdated} rows updated successfully");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
    
    }
}
