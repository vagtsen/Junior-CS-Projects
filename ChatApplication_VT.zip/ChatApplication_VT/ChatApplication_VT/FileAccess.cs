﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatApplication_VT
{
    class FileAccess
    {
        public static System.IO.FileAccess Write { get; private set; }

        //Method for storing message to a text file.
        public static void CreateMessageToText(string date, string description, string text)
        {
            TextWriter txt = new StreamWriter("C:\\Messages\\ChatFile.txt");
            txt.Write($"{date}");
            txt.Write($"");
            txt.Write($"{description}");
            txt.Write($"");
            txt.Write($"{text}");
            txt.Close();
               
        }

      //public static void RemoveLineFromTxtFile(string lineContent, string filename)
        //{
        //    StringBuilder sb = new StringBuilder("");
        //    string[] lines = File.ReadAllLines("C:\\Messages\\ChatFile.txt");
        //    foreach (string line in lines)
        //    {
        //        if (line != lineContent)
        //        {
        //            sb.Append(line);
        //        }
        //    }
        //    if (File.Exists("C:\\Messages\\ChatFile.txt")


        //       {
        //        File.Delete("C:\\Messages\\ChatFile.txt");
        //        }
                          
           
        //    using (FileStream fs = new FileStream("C:\\Messages\\ChatFile.txt", FileMode.OpenOrCreate, FileAccess.Write, FileShare.Write))
        //    {
        //        StreamWriter sw = new StreamWriter(fs);
        //        sw.BaseStream.Seek(0, SeekOrigin.Begin);
        //        sw.Write(sb.ToString());
        //        sw.Flush();
        //        sw.Close();
        //    }
        //}

    }
}
