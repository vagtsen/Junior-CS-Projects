﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ChatApplication_VT
{
    
        public enum Role
        {
            Admin,
            Simple,
            Viewer,
            Editor,
            Deletor
        }

    class Users
    {
            public int UserID { get; set; }
            public string Name { get; set; }
            public string UserName { get; set; }
            public string Password { get; set; }
            public string Role { get; set; }


        public Users()
            {

            }

        public Users(int id, string name, string username, string password, string role)
            {
                UserID = id;
                Name = name;
                UserName = username;
                Password = password;
                Role = role;
            }


        //Method for Creating a User with Role
        public static void CreateUser()
        {
            SqlConnection connection = DataBaseAccess.Connection();
            try
            {
                ConsoleKeyInfo answerUser;
                do
                {
                    Role role;
                    Console.WriteLine("Enter Name");
                    string Name = Console.ReadLine();
                    Console.WriteLine("Enter Username");
                    string username = Console.ReadLine();
                    Console.WriteLine("Enter Password");
                    string password = Console.ReadLine();
                                                     
                    Console.WriteLine("Enter Role ('Simple' for Simple User, 'Viewers' for Viewers, 'Editor' for Viewers and Editors, 'Deletor' for Viewers-Editors and Deleters)");
                    string type = Console.ReadLine().ToLower();
                    role = (Role)Enum.Parse(typeof(Role), type, true);
                    
                    connection.Open();

                    if (DataBaseAccess.UserExists(username) == true)
                    {
                        Console.WriteLine("");
                        Console.WriteLine("User exists try again . . . ");
                    }
                    else
                    {
                        Console.WriteLine(role);
                        Console.ReadKey();
                        SqlCommand cmdInsert = new SqlCommand($"Insert into Users(Name, UserName, Password, Role) VALUES('{Name}','{username}','{password}','{role}')", connection);
                        int rowsInserted = cmdInsert.ExecuteNonQuery();
                        if (rowsInserted > 0)
                        {
                            Console.WriteLine("Insertion Successful");
                            Console.WriteLine($"{rowsInserted} rows Inserted Succesfully");
                        }
                    }
                    bool check = false;
                    do
                    {
                        Console.Write("\nDo You want to continue ? (yes/no) ");
                        answerUser = Console.ReadKey(true);
                        check = !((answerUser.Key == ConsoleKey.Y) || (answerUser.Key == ConsoleKey.N));
                    } while (check);
                    switch (answerUser.Key)
                    {
                        case ConsoleKey.Y: Console.WriteLine("Yes"); break;
                        case ConsoleKey.N: Console.WriteLine("No"); break;
                    }
                } while (answerUser.Key != ConsoleKey.N);


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
    
        //Method for deleting a User
        public static void DeleteUser(string username)
            {
                SqlConnection connection = DataBaseAccess.Connection();
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand($"DELETE FROM Users WHERE Username = '{username}'", connection);
                    int del = command.ExecuteNonQuery();
                    if (del > 0)
                    {
                        Console.WriteLine("User successfully deleted!");
                    }

                    connection.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

        //Method that Updates the Name from Administrator
        public static void UpdateNameByAdmin(string username)
        {
            SqlConnection connection = DataBaseAccess.Connection();
            try
            {
                string input = "";
                double EnterID = 0;

                do
                {
                    Console.WriteLine("Give the id of user to change Name");

                    input = Console.ReadLine();
                    if (!double.TryParse(input, out EnterID))
                        Console.WriteLine("Input does not number. Please try again . . . ");
                } while (!double.TryParse(input, out EnterID));

                Console.WriteLine("Enter a new Nickname for User:");
                string newName = Console.ReadLine();
                connection.Open();
                SqlCommand cmdUpdate = new SqlCommand($"UPDATE Users SET Name = '{newName}' WHERE UserID = '{EnterID}'", connection);
                int rowsUpdated = cmdUpdate.ExecuteNonQuery();
                if (rowsUpdated > 0)
                {
                    Console.WriteLine("Name updated successfully. Press any key to continue . . . ");
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        //Method that Updates the Password from Administrator
        public static void UpdateUserPassWordByAdmin(string username)
        {
            SqlConnection connection = DataBaseAccess.Connection();

            try
            {
                Console.Clear();
                string input = "";
                double idToUpdatePassword = 0;

                do
                {
                    Console.WriteLine("Give the id of user to change Password");
                    input = Console.ReadLine();
                    if (!double.TryParse(input, out idToUpdatePassword))
                        Console.WriteLine("Input does not number. Please try again . . . ");
                } while (!double.TryParse(input, out idToUpdatePassword));

                Console.Write("Enter new username: ");
                string password1 = Console.ReadLine();

                connection.Open();

                SqlCommand command = new SqlCommand($"UPDATE Users SET Password = '{password1}' WHERE UserID = '{idToUpdatePassword}'", connection);
                int updatepass = command.ExecuteNonQuery();
                if (updatepass > 0)
                {
                    Console.WriteLine("Password updated successfully!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        //Method to Update the Name of the User
        public static void UpdateName(string username)
        {
            SqlConnection connection = DataBaseAccess.Connection();
            try
            {
                string input = "";
                double EnterID = 0;

                do
                {
                    Console.WriteLine("Give the id of user to change NickName");

                    input = Console.ReadLine();
                    if (!double.TryParse(input, out EnterID))
                        Console.WriteLine("Input does not number. Please try again . . . ");
                } while (!double.TryParse(input, out EnterID));

                Console.WriteLine("Enter a new Nickname for User:");
                string newName = Console.ReadLine();
                connection.Open();
                SqlCommand cmdUpdate = new SqlCommand($"UPDATE Users SET Name = '{newName}' WHERE UserID = '{EnterID}'", connection);
                int rowsUpdated = cmdUpdate.ExecuteNonQuery();
                if (rowsUpdated > 0)
                {
                    Console.WriteLine("Name updated successfully. Press any key to continue . . . ");
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        //Method 1  used by User for UserName update.
        public static void UpdateUserName(string username)
            {
                SqlConnection connection = DataBaseAccess.Connection();

                try
                {
                    Console.WriteLine($"Current username is {username}");
                    Console.Write("Enter new username: ");
                    string username2 = Console.ReadLine();

                    connection.Open();

                    SqlCommand command = new SqlCommand($"UPDATE Users SET UserName = '{username2}' WHERE UserName = '{username}'", connection);
                    int updatename = command.ExecuteNonQuery();
                    if (updatename > 0)
                    {
                        Console.WriteLine("Username updated successfully!");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }

        //Method 2 Used by User for password update.
        public static void UpdateUserPassWord(string username)
            {
                SqlConnection connection = DataBaseAccess.Connection();

                try
                {
                    Console.Write("Enter new username: ");
                    string password1 = Console.ReadLine();

                    connection.Open();

                    SqlCommand command = new SqlCommand($"UPDATE Users SET Password = '{password1}' WHERE UserName = '{username}'", connection);
                    int updatepass = command.ExecuteNonQuery();
                    if (updatepass > 0)
                    {
                        Console.WriteLine("Password updated successfully!");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        
        //Method used for assigning Roles to each User
        public static void ChangeRole()
            {
                SqlConnection connection = DataBaseAccess.Connection();

            Role Admin = ChatApplication_VT.Role.Admin;
            Role simple = ChatApplication_VT.Role.Simple; ;
            Role viewer= ChatApplication_VT.Role.Viewer; ;
            Role editor= ChatApplication_VT.Role.Editor; ;
            Role deletor= ChatApplication_VT.Role.Deletor; 


            Console.Write("Enter Username: ");
            string username = Console.ReadLine();
            Console.WriteLine("-----------------------");
            Console.WriteLine("Select Role for the User: 1 for Admin , 2 for Simple, 3 for Viewer , 4 for Editor, 5 Deletor ");

                String newrole = Console.ReadLine();
                //int selectedOption;
                while
                    (!int.TryParse(newrole, out int selectedOption))
                {

                    switch (selectedOption)
                    {
                        case 1:
                            try
                            {
                                connection.Open();

                                SqlCommand command = new SqlCommand($"UPDATE Users SET Role = '{Admin}' WHERE UserName = '{username}'", connection);
                                int updateRole = command.ExecuteNonQuery();
                                if (updateRole > 0)
                                {
                                    Console.WriteLine("User's role updated successfully!");
                                    Console.ReadKey();
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            finally
                            {
                                connection.Close();
                            }
                            break;

                        case 2:

                            try
                            {
                                connection.Open();

                                SqlCommand command = new SqlCommand($"UPDATE Users SET Role = '{simple}' WHERE UserName = '{username}'", connection);
                                int updateRole = command.ExecuteNonQuery();
                                if (updateRole > 0)
                                {
                                    Console.WriteLine("User's role updated successfully!");
                                    Console.ReadKey();
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            finally
                            {
                                connection.Close();
                            }
                            break;

                        case 3:

                            try
                            {
                                connection.Open();

                                SqlCommand command = new SqlCommand($"UPDATE Users SET Role = '{viewer}' WHERE UserName = '{username}'", connection);
                                int updateRole = command.ExecuteNonQuery();
                                if (updateRole > 0)
                                {
                                    Console.WriteLine("User's role updated successfully!");
                                    Console.ReadKey();
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            finally
                            {
                                connection.Close();
                            }
                            break;

                        case 4:

                            try
                            {
                                connection.Open();

                                SqlCommand command = new SqlCommand($"UPDATE Users SET Role = '{editor}' WHERE UserName = '{username}'", connection);
                                int updateRole = command.ExecuteNonQuery();
                                if (updateRole > 0)
                                {
                                    Console.WriteLine("User's role updated successfully!");
                                    Console.ReadKey();
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            finally
                            {
                                connection.Close();
                            }
                            break;

                        case 5:

                            try
                            {
                                connection.Open();

                                SqlCommand command = new SqlCommand($"UPDATE Users SET Role = '{deletor}' WHERE UserName = '{username}'", connection);
                                int updateRole = command.ExecuteNonQuery();
                                if (updateRole > 0)
                                {
                                    Console.WriteLine("User's role updated successfully!");
                                    Console.ReadKey();
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            finally
                            {
                                connection.Close();
                            }
                            break;


                        default:
                            break;
                    }
                }
            }

        //Method used for viewing a specific User by the Admin
        public static void ViewUser(string username)
        {
            SqlConnection connection = DataBaseAccess.Connection();

            try
            {
                connection.Open();

                SqlCommand command = new SqlCommand($"SELECT UserID, Name, UserName, Password, Role FROM Users WHERE UserName = '{username}'", connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine(reader.GetInt32(0));
                    Console.WriteLine(reader.GetString(1));
                    Console.WriteLine(reader.GetString(2));
                    Console.WriteLine(reader.GetString(3));
                    Console.WriteLine(reader.GetString(4));

                }

                Console.WriteLine("Press enter to exit");
                Console.ReadLine();
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        //Method used for viewing all Users by the Admin
        public static void ViewAllUsers()
        {
            SqlConnection connection = DataBaseAccess.Connection();
            List<Users> users = new List<Users>();

            try
            {
                connection.Open();

                SqlCommand command = new SqlCommand($"SELECT UserID, Name, UserName, Password, Role FROM Users", connection);
                SqlDataReader reader = command.ExecuteReader();
                Console.WriteLine("Users: ");

                while (reader.Read())
                {
                    Users user = new Users()
                    {
                        UserID = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        UserName = reader.GetString(2),
                        Password = reader.GetString(3),
                        Role = reader.GetString(4)

                    };
                    users.Add(user);
                }
                foreach (Users user in users)
                {
                    Console.WriteLine(user);
                }
                reader.Close();

                Console.WriteLine("Press enter to exit");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }



        }

        public static bool UserExist(string username)
        {
            bool exists = false;
            SqlConnection connection = DataBaseAccess.Connection();

            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand($"SELECT COUNT (*) UserName FROM Users WHERE UserName = '{username}'", connection);
                cmd.Parameters.AddWithValue("@username", username);
                int match = (int)cmd.ExecuteScalar();

                if (match > 0)
                {
                    Console.WriteLine("Username exists!");
                    exists = true;
                }

                else
                {
                    Console.WriteLine("Username does not exist!");
                    exists = false;
                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
            return exists;
        }

        //Overriding the ToString Method
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb
                .Append($"User ID is {UserID}\n")
                .Append($"User Name is {Name}\n")
                .Append($"UserName is {UserName}\n")
                .Append($"User Password is {Password}\n")
                .Append($"User Role is {Role}\n");
            return sb.ToString();
        }


    }

}


