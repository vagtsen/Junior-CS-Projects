﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatApplication_VT
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter a Username");
            // Console.WriteLine("Enter the UserName of the Receiver.");

            string username = Console.ReadLine();
            Menu.AdministratorMenu(username);


        }
    }
}
