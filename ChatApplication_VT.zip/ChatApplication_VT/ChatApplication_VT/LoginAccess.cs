﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatApplication_VT
{

    //Class used for the first login and the appearance of the Menus
    //class LoginAccess 
    //    {

    //    public static string LoginCheck()
    //        {
    //            SqlConnection connection = DataBaseAccess.Connection();

    //            try
    //            {
    //                connection.Open();

    //                Console.Write("Enter Username: ");
    //                string name = Console.ReadLine();
    //                Console.Write("Enter Password: ");
    //                string passwd = Console.ReadLine();
    //                SqlCommand command = new SqlCommand($"SELECT COUNT (*) FROM Users WHERE Username = @username AND Password = @password", connection);
    //                command.Parameters.AddWithValue("@username", name);
    //                command.Parameters.AddWithValue("@password", passwd);
    //                int result = (int)command.ExecuteScalar();

    //                connection.Close();
    //                if (result > 0)
    //                {
    //                    Console.WriteLine("Login Successful!");
    //                    return name;
    //                }
    //                else
    //                {
    //                    Console.WriteLine("Incorrect login. Please try again...");
    //                    return "";
    //                }

    //            }
    //            catch (Exception ex)
    //            {
    //                Console.WriteLine(ex.Message);
    //                return "";
    //            }
    //            finally
    //            {
    //                connection.Close();
    //            }
    //        }
    //    }
    }



