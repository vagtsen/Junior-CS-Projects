﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace NetflixApp.Models
{
    public class NetflixDBContext : DbContext  // have to insert using System.Data.Entity
    {
        public DbSet<Serie> Series { get; set; } //List of Series 

    }
}