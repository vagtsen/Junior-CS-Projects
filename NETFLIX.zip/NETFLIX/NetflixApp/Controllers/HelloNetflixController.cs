﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NetflixApp.Controllers
{
    public class HelloNetflixController : Controller
    {
        // GET: HelloNetflix
        public ActionResult Index()  //By adding a layout in helloNetflix folder (Index.cshtml) .. we can call the index without / index at the url 
        {

            return View();
        }

        public ActionResult Welcome(string name, int ID = 1  ) // defautl value =1 
        {
            //return Content("This is a welcome action..."); //The controller reacts on localhost : by typing the hole url : //http://localhost:53826/hellonetflix/welcome
            //return Content("Hello " + name + "Number of Times =" + ID); //for Example :http://localhost:53826/hellonetflix/welcome?name=Peri&numtimes=1
            //for example http://localhost:53826/Hellonetflix/welcome/4?name=Peri
            ViewBag.Messages = "Hello" + name;
            ViewBag.NumTimes = ID;
            return View();
        }

        [Route ("HelloNetflix/released/{year:range(2015, 2016)}/{month:regex(\\d{2}):range(1, 12)}")]
        public ActionResult ByReleaseDate(int year, int month)
        {
            return Content(year + "-" + month);
        }

       

        //public ActionResult NewTask (string name, int ID)
        //{
        //    ViewBag.Messages = "Hello" + name;
        //    ViewBag.NumTime = ID;

        //       // return  Content("Hello " + name + "Number of Times =" + ID);
        //    return View();
        // }
    }

   }
