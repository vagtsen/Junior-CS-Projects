namespace NetflixApp.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using NetflixApp.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<NetflixApp.Models.NetflixDBContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;

        }

        protected override void Seed(NetflixApp.Models.NetflixDBContext context)  // gia na ginei intialization of data 
        {


            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.
            context.Series.AddOrUpdate(s=>s.Title,
            new Serie
            {
                Title = "Breaking Bad",
                Genre = "Drama",
                ReleaseDate = DateTime.Parse("2004-3-4"),
                Seasons = 6,
                Rating = "Bad"
            },

             new Serie
             {
                 Title = "Loast",
                 Genre = "Mystery",
                 ReleaseDate = DateTime.Parse("2004-8-4"),
                 Seasons = 6,
                 Rating = "Bad"
             },

              new Serie
              {
                  Title = "Peaky Blinders",
                  Genre = "Drama",
                  ReleaseDate = DateTime.Parse("2014-5-4"),
                  Seasons = 4,
                  Rating = "Good"
              },

                new Serie
                {
                    Title = "Dexter",
                    Genre = "Criminal",
                    ReleaseDate = DateTime.Parse("2014-6-4"),
                    Seasons = 4,
                    Rating = "Awful"
                }

            );
        }

    }
}
